package org.usfirst.frc.team7200.robot.commands;

public class Auto_Turn {

	public Auto_Turn() {
		// TODO Auto-generated constructor stub
	}

}
